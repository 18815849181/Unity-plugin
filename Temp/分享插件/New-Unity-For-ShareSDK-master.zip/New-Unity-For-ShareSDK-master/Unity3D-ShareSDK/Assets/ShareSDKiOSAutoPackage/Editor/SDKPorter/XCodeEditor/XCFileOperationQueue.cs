using UnityEngine;
using System.Collections;

namespace cn.sharesdk.unity3d.sdkporter
{
	public class XCFileOperationQueue : System.IDisposable
	{

		public void Dispose()
		{
			
		}
		
	}
}