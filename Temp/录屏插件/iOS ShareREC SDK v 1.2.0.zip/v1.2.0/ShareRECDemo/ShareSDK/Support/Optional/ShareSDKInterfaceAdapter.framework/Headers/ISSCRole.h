//
//  ISSRole.h
//  ShareSDKCoreService
//
//  Created by 冯 鸿杰 on 13-3-1.
//  Copyright (c) 2013年 掌淘科技. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *	@brief	ShareSDK角色用户接口
 */
@protocol ISSCRole <NSObject>

@end
