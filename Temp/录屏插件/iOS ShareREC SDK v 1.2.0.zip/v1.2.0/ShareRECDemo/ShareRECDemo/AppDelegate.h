//
//  AppDelegate.h
//  ShareRECDemo
//
//  Created by 冯 鸿杰 on 14-12-18.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
