//
//  ShareRecListener.h
//  ShareRecCocos2dXGameSample
//
//  Created by vimfung on 14-11-13.
//
//

#ifndef __ShareRecCocos2dXGameSample__ShareRecListener__
#define __ShareRecCocos2dXGameSample__ShareRecListener__

#include <iostream>

namespace com
{
    namespace mob
    {
        /**
         *  ShareRec监听器
         */
        class ShareRECListener
        {
        public:
            ShareRECListener(){}
            ~ShareRECListener(){}
        };
    }
}

#endif /* defined(__ShareRecCocos2dXGameSample__ShareRecListener__) */
