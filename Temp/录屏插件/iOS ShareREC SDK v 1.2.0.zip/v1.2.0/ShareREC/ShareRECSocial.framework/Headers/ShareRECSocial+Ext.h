//
//  ShareRECSocial+Ext.h
//  ShareRECSocial
//
//  Created by liyc on 2016/11/30.
//  Copyright © 2016年 掌淘科技. All rights reserved.
//

#import <ShareRECSocial/ShareRECSocial.h>

@interface ShareRECSocial (Ext)

+ (void)addCustomPlatform:(NSString *)platformName
                  handler:(void (^)(NSString *platformName, NSString *title, NSDictionary *recording))handler;

@end
