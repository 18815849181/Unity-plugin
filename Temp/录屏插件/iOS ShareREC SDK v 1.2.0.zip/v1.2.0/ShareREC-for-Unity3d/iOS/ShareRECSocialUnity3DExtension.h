//
//  ShareRecSocialUnity3DExtension.h
//  ShareRecGameSample
//
//  Created by vimfung on 14-11-14.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * ShareRec社区的Unity3D扩展
 */
@interface ShareRecSocialUnity3DExtension : NSObject

@end
