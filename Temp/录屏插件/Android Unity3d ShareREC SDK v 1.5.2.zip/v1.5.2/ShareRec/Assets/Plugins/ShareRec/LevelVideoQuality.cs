﻿namespace cn.sharerec {
#if UNITY_ANDROID
	public enum LevelVideoQuality {
		LEVEL_SUPER_LOW = 0,
		LEVEL_VERY_LOW = 1,
		LEVEL_LOW = 2,
		LEVEL_MEDIUN = 3,
		LEVEL_HIGH = 4,
		LEVEL_VERY_HIGH = 5,
		LEVEL_SUPER_HIGH = 6
	}
#endif
}